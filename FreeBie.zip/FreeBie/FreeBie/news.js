// Function to toggle language between English and Hindi
function toggleLanguage() {
    var btn = document.querySelector('.english-hindi-btn');
    if (btn.innerText === 'English / हिंदी') {
      btn.innerText = 'हिंदी / English';
      // Perform actions to switch to Hindi language
    } else {
      btn.innerText = 'English / हिंदी';
      // Perform actions to switch to English language
    }
  }

  document.getElementById('search-button').addEventListener('click', function() {
    var searchInputValue = document.getElementById('search-input').value;
    // Perform search functionality with the input value
    console.log('Search query:', searchInputValue);
  });
  